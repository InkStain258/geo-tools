import type { FormulaItem, IndustryType, AgricultureType } from '@/types';

/** 地理计算公式 */
export const geoFormulas: FormulaItem[] = [
  {
    id: 'timezone-diff',
    category: '时差计算',
    name: '时差计算',
    formula: 'ΔT = (λ₁ - λ₂) × 4分钟',
    description: '已知两地经度，计算地方时之差。每差1°经度，时间差4分钟',
    params: [
      { name: 'lng1', label: '已知地经度(°E)', defaultValue: 120, min: -180, max: 180, unit: '°' },
      { name: 'lng2', label: '目标地经度(°E)', defaultValue: 0, min: -180, max: 180, unit: '°' },
    ],
  },
  {
    id: 'local-time',
    category: '时差计算',
    name: '地方时计算',
    formula: 'T₂ = T₁ + (λ₂ - λ₁) × 4min',
    description: '已知一地地方时，计算另一地地方时',
    params: [
      { name: 'time1', label: '已知地时间(时)', defaultValue: 12, min: 0, max: 24, unit: '时' },
      { name: 'lng1', label: '已知地经度(°E)', defaultValue: 120, min: -180, max: 180, unit: '°' },
      { name: 'lng2', label: '目标地经度(°E)', defaultValue: 0, min: -180, max: 180, unit: '°' },
    ],
  },
  {
    id: 'zone-time',
    category: '时差计算',
    name: '区时计算',
    formula: 'T₂ = T₁ + (N₂ - N₁) × 1h',
    description: '已知一地区时，计算另一地区时。N为时区号',
    params: [
      { name: 'time1', label: '已知地区时(时)', defaultValue: 12, min: 0, max: 24, unit: '时' },
      { name: 'zone1', label: '已知地时区', defaultValue: 8, min: -12, max: 12, unit: '区' },
      { name: 'zone2', label: '目标地时区', defaultValue: 0, min: -12, max: 12, unit: '区' },
    ],
  },
  {
    id: 'sun-declination',
    category: '太阳高度角',
    name: '太阳直射点纬度',
    formula: 'δ = 23.5° × sin[(d-81)×360/365]',
    description: '根据日期计算太阳直射点纬度，d为一年中第几天',
    params: [
      { name: 'day', label: '一年中第几天', defaultValue: 172, min: 1, max: 365, unit: '天' },
    ],
  },
  {
    id: 'sun-altitude',
    category: '太阳高度角',
    name: '正午太阳高度角',
    formula: 'H = 90° - |φ - δ|',
    description: 'H为正午太阳高度角，φ为当地纬度，δ为直射点纬度',
    params: [
      { name: 'lat', label: '当地纬度(°N)', defaultValue: 40, min: -90, max: 90, unit: '°' },
      { name: 'decl', label: '直射点纬度(°N)', defaultValue: 23.5, min: -23.5, max: 23.5, unit: '°' },
    ],
  },
  {
    id: 'daylength',
    category: '昼夜长短',
    name: '昼长计算',
    formula: '昼长 = 2/15 × arccos(-tanφ × tanδ) (小时)',
    description: 'φ为当地纬度，δ为直射点纬度',
    params: [
      { name: 'lat', label: '当地纬度(°N)', defaultValue: 40, min: -90, max: 90, unit: '°' },
      { name: 'decl', label: '直射点纬度(°N)', defaultValue: 23.5, min: -23.5, max: 23.5, unit: '°' },
    ],
  },
  {
    id: 'distance',
    category: '距离计算',
    name: '经纬度距离',
    formula: 'd = 111 × √(Δφ² + Δλ²×cos²φ)',
    description: '近似计算同一纬度附近两点的距离(km)',
    params: [
      { name: 'lat1', label: '起点纬度(°)', defaultValue: 40, min: -90, max: 90, unit: '°' },
      { name: 'lng1', label: '起点经度(°)', defaultValue: 116, min: -180, max: 180, unit: '°' },
      { name: 'lat2', label: '终点纬度(°)', defaultValue: 31, min: -90, max: 90, unit: '°' },
      { name: 'lng2', label: '终点经度(°)', defaultValue: 121, min: -180, max: 180, unit: '°' },
    ],
  },
  {
    id: 'slope',
    category: '地形计算',
    name: '坡度计算',
    formula: 'α = arctan(h/d)',
    description: 'h为高差，d为水平距离',
    params: [
      { name: 'h', label: '高差(m)', defaultValue: 100, min: 0, max: 8848, unit: 'm' },
      { name: 'd', label: '水平距离(m)', defaultValue: 1000, min: 1, max: 100000, unit: 'm' },
    ],
  },
  {
    id: 'pop-density',
    category: '人文计算',
    name: '人口密度',
    formula: 'ρ = P/A',
    description: 'P为人口数，A为面积',
    params: [
      { name: 'population', label: '人口(万人)', defaultValue: 1400, min: 0, max: 100000, unit: '万人' },
      { name: 'area', label: '面积(万km²)', defaultValue: 960, min: 1, max: 20000, unit: '万km²' },
    ],
  },
];

/** 工业类型区位数据 */
export const industryTypes: IndustryType[] = [
  {
    id: 'labor-oriented',
    name: '劳动力导向型',
    orientation: '劳动力导向',
    factors: [
      { name: '劳动力成本', weight: 0.35, description: '劳动力成本是首要考虑因素' },
      { name: '劳动力数量', weight: 0.25, description: '需要大量廉价劳动力' },
      { name: '市场距离', weight: 0.15, description: '产品运输便利性' },
      { name: '交通条件', weight: 0.15, description: '交通便利降低运输成本' },
      { name: '政策环境', weight: 0.10, description: '政府优惠政策和税收' },
    ],
  },
  {
    id: 'tech-oriented',
    name: '技术导向型',
    orientation: '技术导向',
    factors: [
      { name: '科技人才', weight: 0.35, description: '高素质科研人员聚集' },
      { name: '研发环境', weight: 0.25, description: '科研院所和高校资源' },
      { name: '信息通达度', weight: 0.20, description: '信息交流便捷' },
      { name: '政策支持', weight: 0.10, description: '科技产业扶持政策' },
      { name: '基础设施', weight: 0.10, description: '通信与交通基础设施' },
    ],
  },
  {
    id: 'resource-oriented',
    name: '原料导向型',
    orientation: '原料导向',
    factors: [
      { name: '原料供应', weight: 0.40, description: '靠近原料产地降低运输成本' },
      { name: '运输条件', weight: 0.25, description: '原料运输的便利性' },
      { name: '能源供应', weight: 0.15, description: '生产过程能源消耗' },
      { name: '水源条件', weight: 0.10, description: '生产用水需求' },
      { name: '市场距离', weight: 0.10, description: '产品销售市场' },
    ],
  },
  {
    id: 'market-oriented',
    name: '市场导向型',
    orientation: '市场导向',
    factors: [
      { name: '市场规模', weight: 0.35, description: '接近消费市场' },
      { name: '交通条件', weight: 0.25, description: '产品快速分销' },
      { name: '信息获取', weight: 0.15, description: '了解市场需求变化' },
      { name: '劳动力素质', weight: 0.15, description: '服务和管理人才' },
      { name: '基础设施', weight: 0.10, description: '物流配送体系' },
    ],
  },
  {
    id: 'power-oriented',
    name: '动力导向型',
    orientation: '动力导向',
    factors: [
      { name: '能源供应', weight: 0.40, description: '靠近能源产地' },
      { name: '运输条件', weight: 0.20, description: '原料和产品运输' },
      { name: '原料供应', weight: 0.15, description: '原材料获取' },
      { name: '水源条件', weight: 0.15, description: '冷却等用水需求' },
      { name: '市场距离', weight: 0.10, description: '产品销售' },
    ],
  },
];

/** 农业类型区位数据 */
export const agricultureTypes: AgricultureType[] = [
  {
    id: 'rice',
    name: '水稻种植业',
    naturalFactors: [
      { name: '气候', weight: 0.30, description: '高温多雨，雨热同期' },
      { name: '地形', weight: 0.25, description: '平原或低地，便于灌溉' },
      { name: '水源', weight: 0.25, description: '灌溉水源充足' },
      { name: '土壤', weight: 0.20, description: '肥沃的水稻土' },
    ],
    humanFactors: [
      { name: '劳动力', weight: 0.30, description: '密集劳动力投入' },
      { name: '种植历史', weight: 0.25, description: '传统经验丰富' },
      { name: '市场', weight: 0.25, description: '粮食需求大' },
      { name: '政策', weight: 0.20, description: '粮食安全政策支持' },
    ],
  },
  {
    id: 'dairy',
    name: '乳畜业',
    naturalFactors: [
      { name: '气候', weight: 0.35, description: '温凉湿润，适合牧草生长' },
      { name: '地形', weight: 0.25, description: '平原或低山丘陵' },
      { name: '水源', weight: 0.20, description: '水源充足' },
      { name: '土壤', weight: 0.20, description: '多汁牧草生长的土壤' },
    ],
    humanFactors: [
      { name: '市场', weight: 0.40, description: '靠近城市消费市场' },
      { name: '交通', weight: 0.25, description: '冷藏运输便利' },
      { name: '技术', weight: 0.20, description: '育种和管理技术' },
      { name: '政策', weight: 0.15, description: '农业补贴政策' },
    ],
  },
  {
    id: 'plantation',
    name: '热带种植园农业',
    naturalFactors: [
      { name: '气候', weight: 0.40, description: '全年高温多雨或干湿季分明' },
      { name: '地形', weight: 0.25, description: '低山丘陵排水良好' },
      { name: '土壤', weight: 0.20, description: '热带土壤' },
      { name: '水源', weight: 0.15, description: '降水丰富' },
    ],
    humanFactors: [
      { name: '劳动力', weight: 0.30, description: '廉价劳动力' },
      { name: '市场', weight: 0.30, description: '国际市场需求' },
      { name: '交通', weight: 0.25, description: '沿海港口运输' },
      { name: '历史', weight: 0.15, description: '殖民历史影响' },
    ],
  },
];
